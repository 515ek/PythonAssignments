## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 2
## Question: Python Program to Sum All the Items in a Dictionary.
###################################################################
sam_dict = {'a': 1, 'b': 2, 'c': 3}
print(sam_dict)
print(sum(sam_dict.values()))