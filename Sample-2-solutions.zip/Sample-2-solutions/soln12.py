## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 2
## Question: Python Program to Concatenate Two Dictionaries Into One.
#######################################################################
dict_1 = {'a': 1, 'b': 2, 'c': 3}
print(dict_1)
dict_2 = {'e': 5, 'f': 6, 'g': 7}
print(dict_2)
dict_1.update(dict_2)
print(dict_1)