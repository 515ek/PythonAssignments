## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 2
## Question: Python Program to check whether two lists are same.
##################################################################
l1 = list(input('Enter the elements of list 1\n').split(' '))
l2 = list(input('Enter the elements of list 2\n').split(' '))
if l1 == l2:
	print('Both lists are same')
else:
	print('Both lists are different')