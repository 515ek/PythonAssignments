## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 2
## Question: Python Program to Create a List of Tuples with the First Element as the Number and Second Element as the Square of the Number.
#############################################################################################################################################
nl = [(i, i*i) for i in range(0,5)]
print(nl)