## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 2
## Question: Python Program to Add a Key-Value Pair to the Dictionary.
########################################################################
key, val = input('Enter the key and the value to be inserted into Dictionary\n').split(' ')
sam_dict = {}
sam_dict[key] = val
print(sam_dict)