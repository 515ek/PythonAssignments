## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Check Whether a Number is Positive or Negative.
################################################################################
n = int(input('Enter the number\n'))
if n < 0:
	print('given number',n,'is Negative')
else:
	print('given number',n,'is Positive')