## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python program to print the lowest index in the string where substring sub is found within the string.
#####################################################################################################################
str1 = input('Enter the string\n')
sstr = input('Enter the sub-string\n')
print(str1.find(sstr))