## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Read Two Numbers and Print Their Quotient and Remainder.
#########################################################################################
a,b = map(int,input('Enter the numbers\n').split(' '))
quo = a//b
rem = a % b
print('Remainder =',rem,'\nQuotient =',quo)