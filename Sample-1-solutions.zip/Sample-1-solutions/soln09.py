## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Reverse a Given Number.
########################################################
num = int(input('Enter the number\n'))
rev_num = ''
for i in str(num):
	rev_num = i + rev_num
print(int(rev_num))