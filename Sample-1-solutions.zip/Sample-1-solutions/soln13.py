## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to print the number of occurrence of a sub string in a given string.
##################################################################################################
str1 = input('Enter the string\n')
sstr = input('Enter the sub-string\n')
print(str1.count(sstr))