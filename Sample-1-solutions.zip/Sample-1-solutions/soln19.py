## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to find the length of string without using any built-in functions.
################################################################################################
str1 = input('Enter the string\n')
count = 0
for ch in str1:
	count += 1
print(count)