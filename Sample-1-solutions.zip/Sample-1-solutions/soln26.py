## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Write a program to generate 10 random integers between 1 to 20 (both inclusive).
###############################################################################################
import random

for i in range(0,10):
	print(random.randint(1,20))