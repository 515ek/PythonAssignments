## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to return true if all characters in the string are alphabetic and there is at least one other character, False.
#############################################################################################################################################
str1 = input('Enter the string\n')
print(str1.isalpha())