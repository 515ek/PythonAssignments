## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Exchange the Values of Two Numbers Without Using a Temporary Variable.
#######################################################################################################
#!/usr/bin/python
a,b = map(int,input('Enter the numbers\n').split(' '))
a,b = b,a
print('a = ',a,'\nb = ',b)