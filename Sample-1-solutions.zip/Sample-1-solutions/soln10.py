## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Calculate the Average of Numbers in a Given List.
##################################################################################
nlist = list(map(int,input('enter the list of numbers\n').split(' ')))
avg = sum(nlist)/len(nlist)
print(avg)