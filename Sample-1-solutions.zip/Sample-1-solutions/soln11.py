## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Count the Number of Digits in a Number.
########################################################################
num = int(input('Enter the Number\n'))
count = len(str(num))
print(count)