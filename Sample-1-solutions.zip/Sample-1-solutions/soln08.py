## Name: Vivek Babu G R
## Date: 26-07-2018
## Assignment: Sample 1
## Question: Python Program to Read a number n and Compute n+nn+nnn.
######################################################################
n = int(input('enter two numbers\n').split(' '))
nsum = n + int(str(n)*2) + int(str(n)*3)
print(nsum)